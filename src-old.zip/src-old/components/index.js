export { default as BottomBar } from "./bottomBar/BottomBar";
